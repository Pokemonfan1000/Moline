<?php

cell2(actionLinkTag(__("Update the board"), "gitpull"));
?>
