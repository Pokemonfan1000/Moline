<?php
	$settings = array(
		"redirects" => array (
			"type" => "textbox",
			"default" => "",
			"name" => "Redirects",
			"help" => "One entry per line. Enter original and new table name separated by spaces. Use dbname.tablename as new table name to redirect to a different DB."
		),
	);
?>
