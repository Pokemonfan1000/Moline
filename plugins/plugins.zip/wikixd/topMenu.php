<?php
	$navigation->add(new PipeMenuLinkEntry('Wiki', 'wiki', "", "", "file-text"));
?>
