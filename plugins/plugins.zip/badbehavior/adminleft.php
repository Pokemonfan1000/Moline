<?php
cell2(actionLinkTag(__("Bad Behavior"), "abusers"));
