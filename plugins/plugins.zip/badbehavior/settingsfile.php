<?php
	$settings = array(
		"email" => array(
			"type" => "text",
			"default" => "example@example.com",
			"name" => "Emergency contact email address",
		),
	);
?>
