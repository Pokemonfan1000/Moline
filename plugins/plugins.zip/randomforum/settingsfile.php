<?php
	$settings = array(
		"forumid" => array(
			"type" => "forum",
			"name" => "Random forum",
		),
	);
?>
