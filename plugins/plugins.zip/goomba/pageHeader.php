<script type="text/javascript" src="<?php print resourceLink("plugins/goomba/goomba.js");?>"></script>
<link rel="stylesheet" type="text/css" href="<?php print resourceLink("plugins/goomba/goomba.css");?>" />

