<?php
if ($loguser['powerlevel'] > 3)
	cell2(actionLinkTag(__("Firewall log"), "shitbugs"));
?>
