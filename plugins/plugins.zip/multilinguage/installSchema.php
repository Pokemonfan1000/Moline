<?php
$tables['users']['fields']['linguage'] = "varchar(16) NOT NULL DEFAULT '-default'";
