[youtube]&hellip;[/youtube] &mdash; video ID or URL <br />
[video]&hellip;[/video] &mdash; requires URL to mp4 or ogv file <br />
[swf ## ##]&hellip;[/swf] &mdash; insert SWF clip<br />
[svg ## ##]&hellip;[/svg] &mdash; insert SVG image<br />
[tindeck]&hellip;[/tindeck] &mdash; link to a song on <a href=\"http://tindeck.com\">Tindeck</a>, song ID only <br />
