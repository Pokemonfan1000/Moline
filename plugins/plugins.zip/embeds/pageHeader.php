<script type="text/javascript" src="<?php print resourceLink("plugins/embeds/swf.js");?>"></script>
<link rel="stylesheet" type="text/css" href="<?php print resourceLink("plugins/embeds/swf.css");?>" />

