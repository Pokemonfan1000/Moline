<?php
$navigation->add(new PipeMenuLinkEntry(__("FAQ"), "faq", "", "", "question"));

