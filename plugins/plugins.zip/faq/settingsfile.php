<?php
$settings = array(
	"faq" => array(
		"type" => "texthtml",
		"name" => "FAQ content",
		"defaultfile" => 'lib/lang/faq_en_US.html',
	),
);
?>
