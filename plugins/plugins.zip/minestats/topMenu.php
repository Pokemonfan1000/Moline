<?php
if (Settings::pluginGet('showlink'))
	print actionLinkTagItem(__("Minecraft stats"), "minestats");
?>
