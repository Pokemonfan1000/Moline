<?php
	$settings = array(
		"server" => array (
			"type" => "text",
			"default" => "irc.digibase.ca",
			"name" => "IRC Server"
		),
		"port" => array (
			"type" => "text",
			"default" => "6667",
			"name" => "IRC Server Port"
		),
		"channel" => array (
			"type" => "text",
			"default" => "#abxd",
			"name" => "IRC Channel"
		),
	);
?>
