<?php $navigation->add(new PipeMenuLinkEntry("IRC Chat", "irc", "", "", "quote-right")); ?>
