<?php
	$settings = array(
		"months" => array (
			"type" => "integer",
			"default" => "3",
			"name" => "Months to lock"
		),
	);
?>
