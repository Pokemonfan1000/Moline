<?php
	$settings = array(
		"hours" => array (
			"type" => "integer",
			"default" => "72",
			"name" => "Last post time limit (hours)"
		),
		"limit" => array (
			"type" => "integer",
			"default" => "10",
			"name" => "Last post count limit"
		),
	);
?>
