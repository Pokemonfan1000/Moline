<?php


$limit = Settings::pluginGet("limit");
doLastPosts(true, $limit);

