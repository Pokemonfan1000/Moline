<?php

//Add a field to the table!
$tables["forums"]["fields"]["rulespost"] = $genericInt;

