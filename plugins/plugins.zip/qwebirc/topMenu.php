<?php 

$link = new PipeMenuLinkEntry("IRC Chat", "qirc", "", "", "quote-right");
$link->newtab = true;
$navigation->add($link); 

