<?php
	$settings = array(
		"server" => array (
			"type" => "text",
			"default" => "http://example.com:9090",
			"name" => "qwebirc location"
		),
		"channels" => array (
			"type" => "text",
			"default" => "abxd,test",
			"name" => "Channels to join"
		),
	);
?>
