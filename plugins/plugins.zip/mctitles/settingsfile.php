<?php
	$mcTitles = array(
		"Open source!",
		"...and freely distributable!",
		"Available on GitHub!",
		"Supports AJAX!",
		"AcmlmBoard XD!",
		"May contain JavaScript!",
		"Fork it!",
		"Internationalized!",
		"What?",
		"Using PHP!",
		":() { :|: & };:",
		"Not made by Acmlm!",
		"Engage!",
		"Call to undefined function!",
		"Colorful!",
		"Doesn't use Tidy!",
		"Probably has bugs!"
	);

	$settings = array(

		"titles" => array(
			"type" => "textbox",
			"name" => "List of titles",
			"default" => implode($mcTitles, "\n")
		)
	);
?>
