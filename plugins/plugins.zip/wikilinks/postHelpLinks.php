[wiki]&hellip;[/wiki] &mdash; link to Wikipedia <br/>
[wiki=&hellip;]&hellip;[/wiki] <br/>
[trope]&hellip;[/trope] &mdash; link to trope <br />
[trope=&hellip;]&hellip;[/trope] <br/>