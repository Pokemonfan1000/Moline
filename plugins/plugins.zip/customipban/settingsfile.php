<?php
$settings = array(
	"text" => array(
		"type" => "texthtml",
		"name" => "HTML content",
	),
);
?>
