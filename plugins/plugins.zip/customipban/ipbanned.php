<?php

echo Settings::pluginGet("text");

?>
