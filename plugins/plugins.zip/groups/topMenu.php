<?php
write("
	<li>
		<a href=\"groups.php\">".__("Groups")."</a>
	</li>
");
?>