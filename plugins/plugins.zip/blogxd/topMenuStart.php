<?php
	$navigation->add(new PipeMenuLinkEntry(Settings::pluginGet("pagename"), "blog", "", "", "comments"));
?>
