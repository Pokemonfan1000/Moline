<?php

$mainPage = "blog";
