<?php
cell2(actionLinkTag(__("Manage User Badges"), "userbadges"));

?>
