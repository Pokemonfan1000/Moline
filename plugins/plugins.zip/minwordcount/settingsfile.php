<?php
	$settings = array(
		"minwords" => array (
			"type" => "integer",
			"default" => "5",
			"name" => "Minimum word count"
		),
	);
?>
