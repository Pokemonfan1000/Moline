<?php
if(isAllowed("viewAvatars"))
	$navigation->add(new PipeMenuLinkEntry(__("Avatars"), "avatarlibrary"));

