<?php

$sideBarStuff .= "UID: ".$post['uid']."<br />";

?>