<?php
	$settings = array(

		"trackingid" => array(
			"type" => "text",
			"name" => "Analytics Tracking ID",
			"default" => "UA-XXXXXXXX-X",
		),
		"dnt" => array(
			"type" => "boolean",
			"name" => "Honor Do Not Track header",
			"default" => "true",
		),
	);
?>
