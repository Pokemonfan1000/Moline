<?php

cell2(actionLinkTag(__("Referral log"), "referrals"));
?>
