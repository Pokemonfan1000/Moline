<?php

$fieldLists["userfields"] .= ",color,hascolor";
