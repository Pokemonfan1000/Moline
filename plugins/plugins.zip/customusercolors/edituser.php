<?php

if ($loguser['powerlevel'] > 1)
{
	$general['appearance']['items']['color'] = array(
		"caption" => "Name color",
		"type" => "color",
	);
	$general['appearance']['items']['hascolor'] = array(
		"caption" => "Enable color",
		"type" => "checkbox",
	);
}


