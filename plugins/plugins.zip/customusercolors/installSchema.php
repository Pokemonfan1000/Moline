<?php

//Add a field to the table!
$tables["users"]["fields"]["color"] =  $var128;
$tables["users"]["fields"]["hascolor"] =  $bool;

