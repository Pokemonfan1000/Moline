<?php
$settings = array(
	"about us" => array(
		"type" => "texthtml",
		"name" => "About us content",
		"defaultfile" => 'lib/lang/aboutus_en_US.html',
	),
);
?>
