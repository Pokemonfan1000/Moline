<?php
$navigation->add(new PipeMenuLinkEntry(__("About us"), "aboutus", "", "", "question"));

