[color=&hellip;]&hellip;[/color] &mdash; set text color<br />
