<?php
bb_help(BB_EMBED);
