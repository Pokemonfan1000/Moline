<?php
include_once('plugins/custombb/defines.php');

bb_help(BB_PRESENTATION);
