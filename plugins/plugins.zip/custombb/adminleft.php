<?php

cell2(actionLinkTag(__("Add new BBCode"), "custombb"));
