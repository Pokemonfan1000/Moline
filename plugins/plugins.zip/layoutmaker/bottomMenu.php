<?php
$navigation->add(new PipeMenuLinkEntry("Layout maker", "layoutmaker"));
