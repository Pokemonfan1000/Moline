<?php
	$bases = array
	(
		array
		(
			"name" => "kaypea",
			"title" => "Simply KP",
			"description" => "Simple background with translucent text box."
		),
		array
		(
			"name" => "fyxe",
			"title" => "Fyxe Style",
			"description" => "Simple background with translucent text box and side image."
		),
		array
		(
			"name" => "kiyoshi",
			"title" => "Kiyoshi's Variant",
			"description" => "Simple background with translucent text box, side image... and an extra bottom panel to really tie the layout together."
		),
		array
		(
			"name" => "dirbaio",
			"title" => "Dirbaio's Glowing Layout",
			"description" => "The layout for Dirbaio."
		),
	);
?>
