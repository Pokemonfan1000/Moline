<?php
$settings = array(
	"numberOfFields" => array(
		"type" => "integer",
		"name" => __("Number of fields"),
		"default" => 10,
	),
);
?>